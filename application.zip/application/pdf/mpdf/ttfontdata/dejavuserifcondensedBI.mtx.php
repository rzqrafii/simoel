<?php
$name='DejaVuSerifCondensed-BoldItalic';
$type='TTF';
$desc=array (
  'Ascent' => 939,
  'Descent' => -236,
  'CapHeight' => 939,
  'Flags' => 262212,
  'FontBBox' => '[-815 -389 1579 1235]',
  'ItalicAngle' => -11,
  'StemV' => 165,
  'MissingWidth' => 540,
);
$up=-63;
$ut=44;
$ttffile='D:/xampp/htdocs/legalbrokers/application/third_party/mpdf/ttfonts/DejaVuSerifCondensed-BoldItalic.ttf';
$TTCfontID='0';
$originalsize=294584;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavuserifcondensedBI';
$panose=' 0 0 2 6 8 6 5 3 5 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>